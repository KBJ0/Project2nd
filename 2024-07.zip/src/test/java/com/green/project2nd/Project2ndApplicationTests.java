package com.green.project2nd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project2ndApplicationTests {

    @Test
    void contextLoads() {
    }

}
