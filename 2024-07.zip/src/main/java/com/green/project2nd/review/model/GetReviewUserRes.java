package com.green.project2nd.review.model;

import lombok.Data;

import java.util.List;

@Data
public class GetReviewUserRes {
    private long reviewSeq;
    private long reviewPlanSeq;
    private long reviewPlmemberSeq;
    private long userSeq;
    private String userName;
    private String reviewContents;
    private String reviewRating;
    private String inputDt;
    private long partySeq;
    private String partyName;
    private String president;

    private List<String> pics;
}