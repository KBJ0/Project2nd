package com.green.project2nd.reviewFav;

public interface ReviewFavMapper {
}
