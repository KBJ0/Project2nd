package com.green.project2nd.budget.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetMemberListRes {
    private long memberSeq;
}
