package com.green.project2nd.user.userexception;

public class DuplicationException extends RuntimeException {
    public DuplicationException(String msg) {
        super(msg);
    }
}
