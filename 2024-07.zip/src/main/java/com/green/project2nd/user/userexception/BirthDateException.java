package com.green.project2nd.user.userexception;

public class BirthDateException extends RuntimeException {
    public BirthDateException(String msg) {
        super(msg);
    }
}
