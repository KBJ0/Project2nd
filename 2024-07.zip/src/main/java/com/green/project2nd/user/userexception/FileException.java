package com.green.project2nd.user.userexception;

public class FileException extends RuntimeException {
    public FileException(String msg) {
        super(msg);
    }
}
